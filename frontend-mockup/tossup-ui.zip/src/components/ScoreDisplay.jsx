
import React from "react";

const ScoreDisplay = ({ score }) => (
  <div className="flex flex-col items-center">
    <p className="text-6xl font-extrabold text-blue-700 animate-pulse">
      {score} 点
    </p>
  </div>
);

export default ScoreDisplay;
